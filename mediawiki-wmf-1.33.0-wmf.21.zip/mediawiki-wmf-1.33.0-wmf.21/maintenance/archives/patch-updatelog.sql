CREATE TABLE /*$wgDBprefix*/updatelog (
  ul_key varchar(255) NOT NULL,
  PRIMARY KEY (ul_key)
) /*$wgDBTableOptions*/;
