<?php
/** Eastern Pwo, Karen languages (ဖၠုံလိက်' / Phlou)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'my';
