<?php
/** Kazakh (Turkey) (‪Qazaqşa (Türkïya)‬)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'kk-latn, kk-cyrl';
