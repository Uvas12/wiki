<?php
/** N'Ko (ߒߞߏ)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$rtl = true;

$digitTransformTable = [
	'0' => '߀', # U+07C0
	'1' => '߁', # U+07C1
	'2' => '߂', # U+07C2
	'3' => '߃', # U+07C3
	'4' => '߄', # U+07C4
	'5' => '߅', # U+07C5
	'6' => '߆', # U+07C6
	'7' => '߇', # U+07C7
	'8' => '߈', # U+07C8
	'9' => '߉', # U+07C9
];
