<?php
/** Tahitian (Reo Mā`ohi)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Sab
 * @author Sainte-Rose (on ty.wikipedia.org)
 * @author Tahitoa (on ty.wikipedia.org)
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = [];
