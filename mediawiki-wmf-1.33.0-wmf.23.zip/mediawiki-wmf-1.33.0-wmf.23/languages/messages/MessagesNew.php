<?php
/** Newari (नेपाल भाषा)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Eukesh
 * @author आलोक
 */

$namespaceNames = [
	NS_MEDIA            => 'माध्यम',
	NS_SPECIAL          => 'विशेष',
	NS_TALK             => 'खँलाबँला',
	NS_USER             => 'छ्येलेमि',
	NS_USER_TALK        => 'छ्येलेमि_खँलाबँला',
	NS_PROJECT_TALK     => '$1_खँलाबँला',
	NS_FILE             => 'किपा',
	NS_FILE_TALK        => 'किपा_खँलाबँला',
	NS_MEDIAWIKI        => 'मिडियाविकि',
	NS_MEDIAWIKI_TALK   => 'मिडियाविकि_खँलाबँला',
	NS_HELP             => 'ग्वाहालि',
	NS_HELP_TALK        => 'ग्वाहालि_खँलाबँला',
	NS_CATEGORY         => 'पुचः',
	NS_CATEGORY_TALK    => 'पुचः_खँलाबँला',
];

$digitTransformTable = [
	'0' => '०', # U+0966
	'1' => '१', # U+0967
	'2' => '२', # U+0968
	'3' => '३', # U+0969
	'4' => '४', # U+096A
	'5' => '५', # U+096B
	'6' => '६', # U+096C
	'7' => '७', # U+096D
	'8' => '८', # U+096E
	'9' => '९', # U+096F
];
