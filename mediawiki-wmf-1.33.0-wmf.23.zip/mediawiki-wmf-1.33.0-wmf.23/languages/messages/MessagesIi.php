<?php
/** Sichuan Yi (ꆇꉙ)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'zh-cn, zh-hans';
