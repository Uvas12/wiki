const LoginPage = require( 'wdio-mediawiki/LoginPage' );

/**
 * @deprecated Use wdio-mediawiki/LoginPage instead.
 */
module.exports = LoginPage;
