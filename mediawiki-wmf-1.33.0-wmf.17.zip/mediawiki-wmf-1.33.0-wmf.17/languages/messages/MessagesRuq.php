<?php
/** Megleno-Romanian (Vlăheşte)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment falls back to Megleno-Romanian (Latin)
 *
 */

$fallback = 'ruq-latn, ro';
