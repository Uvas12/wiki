<?php
/** Navajo (Diné bizaad)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Reedy
 * @author Seb az86556
 * @author לערי ריינהארט
 */

$namespaceNames = [
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Special',
	NS_TALK             => 'Naaltsoos_baa_yáshtiʼ',
	NS_USER             => 'Choyoołʼįįhí',
	NS_USER_TALK        => 'Choyoołʼįįhí_bichʼįʼ_yáshtiʼ',
	NS_PROJECT_TALK     => '$1_baa_yáshtiʼ',
	NS_FILE             => 'Eʼelyaaígíí',
	NS_FILE_TALK        => 'Eʼelyaaígíí_baa_yáshtiʼ',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_baa_yáshtiʼ',
	NS_TEMPLATE         => 'Bee_álnééhí',
	NS_TEMPLATE_TALK    => 'Bee_álnééhí_baa_yáshtiʼ',
	NS_HELP             => 'Anáʼálwoʼ',
	NS_HELP_TALK        => 'Anáʼálwoʼ_baa_yáshtiʼ',
	NS_CATEGORY         => 'Tʼááłáhági_átʼéego',
	NS_CATEGORY_TALK    => 'Tʼááłáhági_átʼéego_baa_yáshtiʼ',
];

$datePreferences = false;
