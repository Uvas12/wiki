<?php
/** Inuktitut (ᐃᓄᒃᑎᑐᑦ/inuktitut)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment Macro language; kept for backward compatibility
 *
 */

$fallback = 'ike-cans';
