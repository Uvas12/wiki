<?php
/** Votic (Vaďďa)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author 2Q
 * @author Aig mest ei varasta
 * @author Andrijko Z.
 * @author Comp1089
 * @author Erdemaslancan
 * @author Paivud
 * @author Trần Nguyễn Minh Huy
 */

$fallback = 'fi';
