<?php
/** Uighur (Uyghurche‎ / ئۇيغۇرچە)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment falls back to Uighur (Arabic script) - ug-arab.
 */

$fallback = 'ug-arab';
