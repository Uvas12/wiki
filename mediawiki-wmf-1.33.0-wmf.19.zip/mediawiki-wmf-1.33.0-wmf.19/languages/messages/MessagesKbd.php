<?php
/** Kabardian
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment falls back to Kabardian (Cyrillic)
 */

$fallback = 'kbd-cyrl';
