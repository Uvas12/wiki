ALTER TABLE /*_*/user_newtalk MODIFY user_id int unsigned NOT NULL default 0;
