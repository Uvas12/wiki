<?php
/** Manipuri/Meitei (মেইতেই লোন্)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */
