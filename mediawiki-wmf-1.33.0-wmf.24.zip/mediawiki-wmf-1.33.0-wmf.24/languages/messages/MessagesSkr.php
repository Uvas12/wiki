<?php
/** Saraiki (multiple scripts)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'skr-arab';
