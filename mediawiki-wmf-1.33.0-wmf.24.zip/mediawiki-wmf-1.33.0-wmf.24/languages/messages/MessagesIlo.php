<?php
/** Iloko (Ilokano)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = [
	NS_MEDIA            => 'Midia',
	NS_SPECIAL          => 'Espesial',
	NS_TALK             => 'Tungtungan',
	NS_USER             => 'Agar-aramat',
	NS_USER_TALK        => 'Agar-aramat_tungtungan',
	NS_PROJECT_TALK     => '$1_tungtungan',
	NS_FILE             => 'Papeles',
	NS_FILE_TALK        => 'Papeles_tungtungan',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_tungtungan',
	NS_TEMPLATE         => 'Plantilia',
	NS_TEMPLATE_TALK    => 'Plantilia_tungtungan',
	NS_HELP             => 'Tulong',
	NS_HELP_TALK        => 'Tulong_tungtungan',
	NS_CATEGORY         => 'Kategoria',
	NS_CATEGORY_TALK    => 'Kategoria_tungtungan',
];
