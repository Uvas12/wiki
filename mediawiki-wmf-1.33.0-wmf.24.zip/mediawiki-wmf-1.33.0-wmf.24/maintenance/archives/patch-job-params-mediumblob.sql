ALTER TABLE /*$wgDBprefix*/job
MODIFY COLUMN job_params mediumblob NOT NULL;
