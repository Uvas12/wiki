CREATE INDEX /*i*/log_user_text_time ON /*_*/logging (log_user_text, log_timestamp);
