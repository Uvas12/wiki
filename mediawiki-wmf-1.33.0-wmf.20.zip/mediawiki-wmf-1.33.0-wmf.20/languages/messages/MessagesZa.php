<?php
/** Zhuang (Vahcuengh)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Biŋhai
 * @author Hakka
 */

$fallback = 'zh-hans';
