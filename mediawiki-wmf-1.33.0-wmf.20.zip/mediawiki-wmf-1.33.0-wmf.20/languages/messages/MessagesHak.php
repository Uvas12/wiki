<?php
/** Hakka (客家語/Hak-kâ-ngî)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'zh-hant';
