<?php
/** Akan (Akan)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = [
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Soronko',
	NS_TALK             => 'Nkɔmmɔ',
	NS_USER             => 'Odwumanyɛni',
	NS_USER_TALK        => 'Odwumanyɛni_nkɔmmɔbea',
	NS_PROJECT_TALK     => '$1_nkɔmmɔ',
	NS_FILE             => 'File',
	NS_FILE_TALK        => 'File_nkɔmmɔ',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_nkɔmmɔ',
	NS_TEMPLATE         => 'Nhwɛsode',
	NS_TEMPLATE_TALK    => 'Nhwɛsode_nkɔmmɔbea',
	NS_HELP             => 'Boa',
	NS_HELP_TALK        => 'Mmoa_nkɔmmɔbea',
	NS_CATEGORY         => 'Nkyekyem',
	NS_CATEGORY_TALK    => 'Nkyekyem_nkɔmmɔbea',
];
