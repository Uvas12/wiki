<?php
/** Līvõ kēļ (Līvõ kēļ)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Andrijko Z.
 * @author Erdemaslancan
 * @author Ohpuu
 * @author Warbola
 */

$fallback = 'et';
