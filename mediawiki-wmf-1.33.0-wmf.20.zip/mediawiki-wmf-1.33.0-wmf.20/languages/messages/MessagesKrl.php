<?php
/** Karelian (Karlaj)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'fi'; // T137415
