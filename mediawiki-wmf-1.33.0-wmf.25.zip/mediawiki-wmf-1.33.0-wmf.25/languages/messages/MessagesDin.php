<?php
/** Dinka (Thuɔŋjäŋ)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = [
	NS_MEDIA            => 'Ciɛl',
	NS_SPECIAL          => 'Këcëweek',
	NS_TALK             => 'Jam',
	NS_USER             => 'Dulooi',
	NS_USER_TALK        => 'Jam_kekë_dulooi',
	NS_PROJECT_TALK     => 'Jam_wɛ̈t_ë_$1',
	NS_FILE             => 'Apamduööt',
	NS_FILE_TALK        => 'Jam_wɛ̈t_ë_apamduööt',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Jam_wɛ̈t_ë_MediaWiki',
	NS_TEMPLATE         => 'Macuëc',
	NS_TEMPLATE_TALK    => 'Jam_wɛ̈t_ë_macuëc',
	NS_HELP             => 'Kuɔny',
	NS_HELP_TALK        => 'Jam_wɛ̈t_ë_kuɔny',
	NS_CATEGORY         => 'Bekätakthook',
	NS_CATEGORY_TALK    => 'Jam_wɛ̈t_ë_bekätakthook',
];

$linkTrail = '/^([äëɛɛ̈éɣïŋöɔɔ̈óa-z]+)(.*)$/sDu';
