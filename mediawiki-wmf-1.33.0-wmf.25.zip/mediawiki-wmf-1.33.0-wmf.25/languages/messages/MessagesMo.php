<?php
/** Moldavian (молдовеняскэ)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Comp1089
 * @author Node ue
 * @author לערי ריינהארט
 */

$fallback = 'ro';

$specialPageAliases = [
	'CreateAccount'             => [ 'КреареКонт' ],
	'Preferences'               => [ 'Преферинце' ],
	'Recentchanges'             => [ 'Модификэрьреченте' ],
];
