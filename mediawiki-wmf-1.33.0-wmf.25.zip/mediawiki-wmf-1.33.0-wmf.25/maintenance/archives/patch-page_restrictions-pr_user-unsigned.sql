ALTER TABLE /*_*/page_restrictions MODIFY pr_user int unsigned NULL;
