ALTER TABLE /*_*/recentchanges MODIFY COLUMN rc_ip varbinary(40) NOT NULL default '';
