<?php
/** Kurdish (Kurdî / كوردی)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'ku-latn';
