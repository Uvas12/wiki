<?php
/** West-Vlams (West-Vlams)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author DasRakel
 * @author Tbc
 * @author לערי ריינהארט
 */

$fallback = 'nl';

$namespaceNames = [
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Specioal',
	NS_TALK             => 'Discuusje',
	NS_USER             => 'Gebruker',
	NS_USER_TALK        => 'Discuusje_gebruker',
	NS_PROJECT_TALK     => 'Discuusje_$1',
	NS_FILE             => 'Ofbeeldienge',
	NS_FILE_TALK        => 'Discuusje_ofbeeldienge',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Discuusje_MediaWiki',
	NS_TEMPLATE         => 'Patrôon',
	NS_TEMPLATE_TALK    => 'Discuusje_patrôon',
	NS_HELP             => 'Ulpe',
	NS_HELP_TALK        => 'Discuusje_ulpe',
	NS_CATEGORY         => 'Categorie',
	NS_CATEGORY_TALK    => 'Discuusje_categorie',
];
