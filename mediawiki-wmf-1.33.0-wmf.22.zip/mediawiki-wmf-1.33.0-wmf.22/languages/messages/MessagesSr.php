<?php
/** Serbian (српски / srpski)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Milicevic01
 * @author Misos
 * @author Terik
 * @author Жељко Тодоровић
 * @author Михајло Анђелковић
 */

$fallback = 'sr-ec';
$linkTrail = '/^([abvgdđežzijklljmnnjoprstćufhcčdžšабвгдђежзијклљмнњопрстћуфхцчџш]+)(.*)$/usD';
