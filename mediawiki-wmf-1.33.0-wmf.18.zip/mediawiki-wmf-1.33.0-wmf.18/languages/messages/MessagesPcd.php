<?php
/** Picard (Picard)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Geoleplubo
 * @author Hercule
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = [];
