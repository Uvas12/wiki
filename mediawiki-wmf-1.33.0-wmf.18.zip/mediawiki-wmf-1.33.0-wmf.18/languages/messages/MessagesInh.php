<?php
/** Ingush (ГӀалгӀай)
*
* To improve a translation please visit https://translatewiki.net
*
* @ingroup Language
* @file
*
*/

$fallback = 'ru';

$namespaceNames = [
	NS_MEDIA            => 'Медиа',
	NS_SPECIAL          => 'Гӏулакха',
	NS_MAIN             => '',
	NS_TALK             => 'Ювцар',
	NS_USER             => 'Доакъашхо',
	NS_USER_TALK        => 'Доакъашхочун_дувцар',
	NS_PROJECT_TALK     => '$1_ювцар',
	NS_FILE             => 'Файл',
	NS_FILE_TALK        => 'Файл_ювцар',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_ювцар',
	NS_TEMPLATE         => 'Ло',
	NS_TEMPLATE_TALK    => 'Ло_бувцар',
	NS_HELP             => 'Новкъостал',
	NS_HELP_TALK        => 'Новкъостал_дувцар',
	NS_CATEGORY         => 'ОагӀат',
	NS_CATEGORY_TALK    => 'ОагӀат_ювцар',
];
