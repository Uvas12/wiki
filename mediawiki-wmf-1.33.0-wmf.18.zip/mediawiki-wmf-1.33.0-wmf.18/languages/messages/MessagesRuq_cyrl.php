<?php
/** Megleno-Romanian (Cyrillic script) (Влахесте)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Andrijko Z.
 * @author Кумулај Маркус
 * @author Макѕе
 * @author Приетен тев
 */

$fallback = 'mk';
