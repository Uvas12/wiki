ALTER TABLE /*_*/user_groups
	MODIFY COLUMN ug_group varbinary(255) NOT NULL default '';
